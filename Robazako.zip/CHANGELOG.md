# Changelog

## [1.0.5] - 2024-04-13
### Fixed
- Data saving and recovery

## [1.0.4] - 2024-03-30
### Fixed
- Shift_JIS table

## [1.0.3] - 2024-03-29
### Fixed
- README
- Status checks in StarPRNT mode

## [1.0.2] - 2024-03-23
### Fixed
- README

## [1.0.1] - 2024-03-20
### Fixed
- README
- HTML to hide translation popups

## [1.0.0] - 2024-03-18
### Added
- First edition
